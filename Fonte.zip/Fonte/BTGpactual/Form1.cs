﻿using System;
using System.ComponentModel;
using System.Configuration;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using System.Xml.Linq;
using BTGpactual.BTGDataSet1TableAdapters;
using static System.Net.Mime.MediaTypeNames;


namespace BTGpactual
{
    public partial class Form1 : Form
    {
        public object Configuration { get; private set; }
        public object OnMessageSent { get; private set; }

        public string connectionString = Properties.Settings.Default.BTGConnectionString.ToString();

        public string limitePublic;

        public  PixLimite pix = new PixLimite();

        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            this.limite1TableAdapter1.Fill(this.bTGDataSet.Limite1);
        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                //this.Limite1TableAdapter.FillBy(this.bTGDataSet1.Limite1);
                this.limite1TableAdapter1.Fill(this.bTGDataSet.Limite1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

    

        private void LimparCampos() 
        {
            txtDocumento.Text = "";
            txtAgencia.Text = "";
            txtConta.Text = "";
            txtLimite.Text = "";
            txtDocumentoAlter.Text = "";
            txtLimiteTransferencia.Text = "";

        }

       


        private void dgvDocumento_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvDocumento.RowCount > 0)
            {
                txtDocumento.Text = dgvDocumento[0, dgvDocumento.CurrentRow.Index].Value.ToString();
                txtAgencia.Text = dgvDocumento[1, dgvDocumento.CurrentRow.Index].Value.ToString();
                txtConta.Text = dgvDocumento[2, dgvDocumento.CurrentRow.Index].Value.ToString();
                txtLimite.Text = dgvDocumento[3, dgvDocumento.CurrentRow.Index].Value.ToString();
                txtDocumentoAlter.Text = dgvDocumento[0, dgvDocumento.CurrentRow.Index].Value.ToString();

            }
        }

        private void tsbExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtDocumento.Text != "")
                {
                    using (var sc = new SqlConnection(connectionString))
                    using (var cmd = sc.CreateCommand())
                    {
                        sc.Open();
                        cmd.CommandText = "DELETE FROM LIMITE1 WHERE Documento = @Documento";
                        cmd.Parameters.AddWithValue("@Documento", txtDocumento.Text);
                        cmd.ExecuteNonQuery();
                    }

                    //this.limiteTableAdapter.Fill(this.bTGDataSet1.Limite);
                    this.limite1TableAdapter1.Fill(this.bTGDataSet.Limite1);
                    LimparCampos();

                    MessageBox.Show("Excluído com Sucesso", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

                }
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }

        private void tsbIncluir_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtDocumento.Text != "")
                {

                    using (var sc = new SqlConnection(connectionString))
                    using (var cmd = sc.CreateCommand())
                    {
                        sc.Open();
                        cmd.CommandText = "INSERT INTO LIMITE1( Documento, NumeroAgencia, NumeroConta, Limite )   VALUES(@param1,@param2,@param3,@param4)";
                        cmd.Parameters.AddWithValue("@param1", txtDocumento.Text);
                        cmd.Parameters.AddWithValue("@param2", txtAgencia.Text);
                        cmd.Parameters.AddWithValue("@param3", txtConta.Text);
                        cmd.Parameters.AddWithValue("@param4", txtLimite.Text);

                        cmd.ExecuteNonQuery();

                        sc.Close();

                    }

                    //this.limiteTableAdapter.Fill(this.bTGDataSet1.Limite);
                    this.limite1TableAdapter1.Fill(this.bTGDataSet.Limite1);
                    LimparCampos();

                    MessageBox.Show("Incluido com Sucesso", "", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    txtDocumento.Focus();
                }
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }


        private void tsbSair_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.OpenForms[0].Close();
        }

        private void txtLimite_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != Convert.ToChar(Keys.Back))
            {
                if (e.KeyChar == ',')
                {
                    e.Handled = (txtLimite .Text.Contains(","));
                }
                else
                    e.Handled = true;
            }
        }

        private void tsbAlterar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtDocumento.Text != "")
                {
                    using (var sc = new SqlConnection(connectionString))
                    using (var cmd = sc.CreateCommand())
                    {
                        sc.Open();

                        string documentoAlter = txtDocumentoAlter.Text;

                        cmd.CommandText = "UPDATE LIMITE1 SET Documento = @Documento, NumeroAgencia = @NumeroAgencia, NumeroConta = @NumeroConta, Limite = @Limite    WHERE Documento =" + documentoAlter;

                        cmd.Parameters.AddWithValue("@Documento", txtDocumento.Text);
                        cmd.Parameters.AddWithValue("@NumeroAgencia", txtAgencia.Text);
                        cmd.Parameters.AddWithValue("@NumeroConta", txtConta.Text);
                        cmd.Parameters.AddWithValue("@Limite", txtLimite.Text);

                        cmd.ExecuteNonQuery();

                        sc.Close();

                    }

                    //this.limiteTableAdapter.Fill(this.bTGDataSet1.Limite);
                    this.limite1TableAdapter1.Fill(this.bTGDataSet.Limite1);
                    LimparCampos();

                    MessageBox.Show("Alterado com Sucesso", "", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    txtDocumento.Focus();
                }
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }

        private void btnPix_Click(object sender, EventArgs e)
        {

            if (txtDocumento.Text != "")
            {

                double limite = double.Parse(txtLimite.Text);
                double limiteTransferencia = double.Parse(txtLimiteTransferencia.Text);

                if (limite >= limiteTransferencia)
                {
                    // Faz a transferencia;

                    limite = limite - limiteTransferencia;


                    using (var sc = new SqlConnection(connectionString))
                    using (var cmd = sc.CreateCommand())
                    {
                        sc.Open();

                        string documentoAlter = txtDocumentoAlter.Text;

                        cmd.CommandText = "UPDATE LIMITE1 SET Documento = @Documento, Limite = @Limite    WHERE Documento =" + documentoAlter;

                        cmd.Parameters.AddWithValue("@Documento", txtDocumento.Text);
                        cmd.Parameters.AddWithValue("@Limite", limite);

                        cmd.ExecuteNonQuery();

                        sc.Close();

                    }

                    //this.limiteTableAdapter.Fill(this.bTGDataSet1.Limite);
                    this.limite1TableAdapter1.Fill(this.bTGDataSet.Limite1);
                    LimparCampos();

                    MessageBox.Show("PIX Realizado com Sucesso", "", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    txtDocumento.Focus();
                }
                else
                {
                    MessageBox.Show("Valor Maior que o Limite", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void txtLimiteTransferencia_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != Convert.ToChar(Keys.Back))
            {
                if (e.KeyChar == ',')
                {
                    e.Handled = (txtLimiteTransferencia.Text.Contains(","));
                }
                else
                    e.Handled = true;
            }
        }
    }
} 
