﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BTGpactual
{
    public  class PixLimite
    {

        private string pix;

        // Propriedade pública com lógica personalizada
        public string Pix
        {
            get { return pix; }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    pix = value;
                }
            }
        }
    }

    //public class PixLimites
    //{
        
    //}
}
