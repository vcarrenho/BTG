﻿namespace BTGpactual
{


    partial class BTGDataSet1
    {
    }
}

namespace BTGpactual.BTGDataSet1TableAdapters
{


    public partial class Limite1TableAdapter
    {
    }
}
