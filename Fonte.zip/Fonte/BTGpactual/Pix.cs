﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTGpactual
{
    public partial class Pix : Form
    {
        // Define um evento para passar dados de volta
        public event Action<string> OnMessageSent;

        public Pix()
        {
            InitializeComponent();
        }

        private void tsbSair_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.OpenForms[0].Close();
        }

        private void Pix_Load(object sender, EventArgs e)
        {
            //Program.PixLimite pix = new Program.PixLimite();


            //txtLimite.Text = pix.Pix;


            // Dispara o evento passando a mensagem para o Form1
            OnMessageSent?.Invoke(txtLimite.Text);

            // Fecha o Form2
            //this.Close();
        }
    }
}
