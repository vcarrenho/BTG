﻿namespace System.Configuration
{
    internal class ConfigurationManager
    {
        public static object ConnectionStrings { get; internal set; }
    }
}