﻿namespace BTGpactual
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button2 = new System.Windows.Forms.Button();
            this.dgvDocumento = new System.Windows.Forms.DataGridView();
            this.limite1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bTGDataSet = new BTGpactual.BTGDataSet();
            this.limiteBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.lblDocumento = new System.Windows.Forms.Label();
            this.lblAgencia = new System.Windows.Forms.Label();
            this.lblConta = new System.Windows.Forms.Label();
            this.lblLimite = new System.Windows.Forms.Label();
            this.txtDocumento = new System.Windows.Forms.TextBox();
            this.txtAgencia = new System.Windows.Forms.TextBox();
            this.txtConta = new System.Windows.Forms.TextBox();
            this.txtLimite = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnPix = new System.Windows.Forms.Button();
            this.txtDocumentoAlter = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.limiteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btgDataSet11 = new BTGpactual.BTGDataSet1();
            this.tsbExcluir = new System.Windows.Forms.ToolStripButton();
            this.tsbIncluir = new System.Windows.Forms.ToolStripButton();
            this.tsbAlterar = new System.Windows.Forms.ToolStripButton();
            this.tsbSair = new System.Windows.Forms.ToolStripButton();
            this.fillByToolStrip = new System.Windows.Forms.ToolStrip();
            this.Limite1TableAdapter = new BTGpactual.BTGDataSet1TableAdapters.TableAdapterManager();
            this.limite1TableAdapter1 = new BTGpactual.BTGDataSetTableAdapters.Limite1TableAdapter();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtLimiteTransferencia = new System.Windows.Forms.TextBox();
            this.documentoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numeroAgenciaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numeroContaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.limiteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDocumento)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.limite1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bTGDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.limiteBindingSource1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.limiteBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btgDataSet11)).BeginInit();
            this.fillByToolStrip.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(0, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 34;
            // 
            // dgvDocumento
            // 
            this.dgvDocumento.AllowUserToOrderColumns = true;
            this.dgvDocumento.AutoGenerateColumns = false;
            this.dgvDocumento.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDocumento.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.documentoDataGridViewTextBoxColumn,
            this.numeroAgenciaDataGridViewTextBoxColumn,
            this.numeroContaDataGridViewTextBoxColumn,
            this.limiteDataGridViewTextBoxColumn});
            this.dgvDocumento.DataSource = this.limite1BindingSource;
            this.dgvDocumento.Location = new System.Drawing.Point(6, 21);
            this.dgvDocumento.Name = "dgvDocumento";
            this.dgvDocumento.RowHeadersWidth = 51;
            this.dgvDocumento.RowTemplate.Height = 24;
            this.dgvDocumento.Size = new System.Drawing.Size(794, 189);
            this.dgvDocumento.TabIndex = 2;
            this.dgvDocumento.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDocumento_CellClick);
            // 
            // limite1BindingSource
            // 
            this.limite1BindingSource.DataMember = "Limite1";
            this.limite1BindingSource.DataSource = this.bTGDataSet;
            // 
            // bTGDataSet
            // 
            this.bTGDataSet.DataSetName = "BTGDataSet";
            this.bTGDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // limiteBindingSource1
            // 
            this.limiteBindingSource1.DataMember = "Limite";
            // 
            // lblDocumento
            // 
            this.lblDocumento.AutoSize = true;
            this.lblDocumento.Location = new System.Drawing.Point(12, 30);
            this.lblDocumento.Name = "lblDocumento";
            this.lblDocumento.Size = new System.Drawing.Size(79, 16);
            this.lblDocumento.TabIndex = 4;
            this.lblDocumento.Text = "Documento:";
            // 
            // lblAgencia
            // 
            this.lblAgencia.AutoSize = true;
            this.lblAgencia.Location = new System.Drawing.Point(15, 62);
            this.lblAgencia.Name = "lblAgencia";
            this.lblAgencia.Size = new System.Drawing.Size(60, 16);
            this.lblAgencia.TabIndex = 5;
            this.lblAgencia.Text = "Agência:";
            // 
            // lblConta
            // 
            this.lblConta.AutoSize = true;
            this.lblConta.Location = new System.Drawing.Point(15, 94);
            this.lblConta.Name = "lblConta";
            this.lblConta.Size = new System.Drawing.Size(45, 16);
            this.lblConta.TabIndex = 6;
            this.lblConta.Text = "Conta:";
            // 
            // lblLimite
            // 
            this.lblLimite.AutoSize = true;
            this.lblLimite.Location = new System.Drawing.Point(15, 127);
            this.lblLimite.Name = "lblLimite";
            this.lblLimite.Size = new System.Drawing.Size(45, 16);
            this.lblLimite.TabIndex = 7;
            this.lblLimite.Text = "Limite:";
            // 
            // txtDocumento
            // 
            this.txtDocumento.Location = new System.Drawing.Point(97, 30);
            this.txtDocumento.Name = "txtDocumento";
            this.txtDocumento.Size = new System.Drawing.Size(176, 22);
            this.txtDocumento.TabIndex = 0;
            // 
            // txtAgencia
            // 
            this.txtAgencia.Location = new System.Drawing.Point(97, 59);
            this.txtAgencia.Name = "txtAgencia";
            this.txtAgencia.Size = new System.Drawing.Size(84, 22);
            this.txtAgencia.TabIndex = 1;
            // 
            // txtConta
            // 
            this.txtConta.Location = new System.Drawing.Point(97, 91);
            this.txtConta.Name = "txtConta";
            this.txtConta.Size = new System.Drawing.Size(120, 22);
            this.txtConta.TabIndex = 2;
            // 
            // txtLimite
            // 
            this.txtLimite.Location = new System.Drawing.Point(97, 124);
            this.txtLimite.Name = "txtLimite";
            this.txtLimite.Size = new System.Drawing.Size(141, 22);
            this.txtLimite.TabIndex = 3;
            this.txtLimite.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLimite_KeyPress);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtDocumentoAlter);
            this.groupBox1.Controls.Add(this.txtDocumento);
            this.groupBox1.Controls.Add(this.txtLimite);
            this.groupBox1.Controls.Add(this.lblDocumento);
            this.groupBox1.Controls.Add(this.txtConta);
            this.groupBox1.Controls.Add(this.lblAgencia);
            this.groupBox1.Controls.Add(this.txtAgencia);
            this.groupBox1.Controls.Add(this.lblConta);
            this.groupBox1.Controls.Add(this.lblLimite);
            this.groupBox1.Location = new System.Drawing.Point(18, 21);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(368, 164);
            this.groupBox1.TabIndex = 31;
            this.groupBox1.TabStop = false;
            // 
            // btnPix
            // 
            this.btnPix.Location = new System.Drawing.Point(146, 111);
            this.btnPix.Name = "btnPix";
            this.btnPix.Size = new System.Drawing.Size(118, 32);
            this.btnPix.TabIndex = 9;
            this.btnPix.Text = "PIX";
            this.btnPix.UseVisualStyleBackColor = true;
            this.btnPix.Click += new System.EventHandler(this.btnPix_Click);
            // 
            // txtDocumentoAlter
            // 
            this.txtDocumentoAlter.Location = new System.Drawing.Point(220, 62);
            this.txtDocumentoAlter.Name = "txtDocumentoAlter";
            this.txtDocumentoAlter.Size = new System.Drawing.Size(142, 22);
            this.txtDocumentoAlter.TabIndex = 8;
            this.txtDocumentoAlter.Visible = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dgvDocumento);
            this.groupBox2.Location = new System.Drawing.Point(18, 202);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(813, 237);
            this.groupBox2.TabIndex = 32;
            this.groupBox2.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox5);
            this.groupBox3.Controls.Add(this.groupBox1);
            this.groupBox3.Controls.Add(this.groupBox2);
            this.groupBox3.Location = new System.Drawing.Point(12, 30);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(852, 452);
            this.groupBox3.TabIndex = 33;
            this.groupBox3.TabStop = false;
            // 
            // limiteBindingSource
            // 
            this.limiteBindingSource.DataMember = "Limite";
            // 
            // btgDataSet11
            // 
            this.btgDataSet11.DataSetName = "BTGDataSet1";
            this.btgDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tsbExcluir
            // 
            this.tsbExcluir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbExcluir.Image = ((System.Drawing.Image)(resources.GetObject("tsbExcluir.Image")));
            this.tsbExcluir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbExcluir.Name = "tsbExcluir";
            this.tsbExcluir.Size = new System.Drawing.Size(29, 24);
            this.tsbExcluir.Text = "Excluir";
            this.tsbExcluir.Click += new System.EventHandler(this.tsbExcluir_Click);
            // 
            // tsbIncluir
            // 
            this.tsbIncluir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbIncluir.Image = ((System.Drawing.Image)(resources.GetObject("tsbIncluir.Image")));
            this.tsbIncluir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbIncluir.Name = "tsbIncluir";
            this.tsbIncluir.Size = new System.Drawing.Size(29, 28);
            this.tsbIncluir.Text = "tsbIncluir";
            this.tsbIncluir.ToolTipText = "Incluir";
            this.tsbIncluir.Click += new System.EventHandler(this.tsbIncluir_Click);
            // 
            // tsbAlterar
            // 
            this.tsbAlterar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAlterar.Image = ((System.Drawing.Image)(resources.GetObject("tsbAlterar.Image")));
            this.tsbAlterar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAlterar.Name = "tsbAlterar";
            this.tsbAlterar.Size = new System.Drawing.Size(29, 28);
            this.tsbAlterar.Text = "Alterar";
            this.tsbAlterar.Click += new System.EventHandler(this.tsbAlterar_Click);
            // 
            // tsbSair
            // 
            this.tsbSair.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSair.Image = ((System.Drawing.Image)(resources.GetObject("tsbSair.Image")));
            this.tsbSair.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSair.Name = "tsbSair";
            this.tsbSair.Size = new System.Drawing.Size(29, 28);
            this.tsbSair.Text = "Sair";
            this.tsbSair.Click += new System.EventHandler(this.tsbSair_Click);
            // 
            // fillByToolStrip
            // 
            this.fillByToolStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.fillByToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbExcluir,
            this.tsbIncluir,
            this.tsbAlterar,
            this.tsbSair});
            this.fillByToolStrip.Location = new System.Drawing.Point(0, 0);
            this.fillByToolStrip.Name = "fillByToolStrip";
            this.fillByToolStrip.Size = new System.Drawing.Size(876, 27);
            this.fillByToolStrip.TabIndex = 3;
            this.fillByToolStrip.Text = "fillByToolStrip";
            // 
            // Limite1TableAdapter
            // 
            this.Limite1TableAdapter.BackupDataSetBeforeUpdate = false;
            this.Limite1TableAdapter.Connection = null;
            this.Limite1TableAdapter.Limite1TableAdapter = null;
            this.Limite1TableAdapter.UpdateOrder = BTGpactual.BTGDataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // limite1TableAdapter1
            // 
            this.limite1TableAdapter1.ClearBeforeFill = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtLimiteTransferencia);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Location = new System.Drawing.Point(6, 21);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(364, 73);
            this.groupBox4.TabIndex = 10;
            this.groupBox4.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 16);
            this.label1.TabIndex = 9;
            this.label1.Text = "Limite Transferência:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnPix);
            this.groupBox5.Controls.Add(this.groupBox4);
            this.groupBox5.Location = new System.Drawing.Point(419, 21);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(412, 165);
            this.groupBox5.TabIndex = 33;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "PIX";
            // 
            // txtLimiteTransferencia
            // 
            this.txtLimiteTransferencia.Location = new System.Drawing.Point(140, 27);
            this.txtLimiteTransferencia.Name = "txtLimiteTransferencia";
            this.txtLimiteTransferencia.Size = new System.Drawing.Size(141, 22);
            this.txtLimiteTransferencia.TabIndex = 10;
            this.txtLimiteTransferencia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLimiteTransferencia_KeyPress);
            // 
            // documentoDataGridViewTextBoxColumn
            // 
            this.documentoDataGridViewTextBoxColumn.DataPropertyName = "Documento";
            this.documentoDataGridViewTextBoxColumn.HeaderText = "Documento";
            this.documentoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.documentoDataGridViewTextBoxColumn.Name = "documentoDataGridViewTextBoxColumn";
            this.documentoDataGridViewTextBoxColumn.Width = 125;
            // 
            // numeroAgenciaDataGridViewTextBoxColumn
            // 
            this.numeroAgenciaDataGridViewTextBoxColumn.DataPropertyName = "NumeroAgencia";
            this.numeroAgenciaDataGridViewTextBoxColumn.HeaderText = "Número Agência";
            this.numeroAgenciaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.numeroAgenciaDataGridViewTextBoxColumn.Name = "numeroAgenciaDataGridViewTextBoxColumn";
            this.numeroAgenciaDataGridViewTextBoxColumn.Width = 140;
            // 
            // numeroContaDataGridViewTextBoxColumn
            // 
            this.numeroContaDataGridViewTextBoxColumn.DataPropertyName = "NumeroConta";
            this.numeroContaDataGridViewTextBoxColumn.HeaderText = "Número Conta";
            this.numeroContaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.numeroContaDataGridViewTextBoxColumn.Name = "numeroContaDataGridViewTextBoxColumn";
            this.numeroContaDataGridViewTextBoxColumn.Width = 125;
            // 
            // limiteDataGridViewTextBoxColumn
            // 
            this.limiteDataGridViewTextBoxColumn.DataPropertyName = "Limite";
            this.limiteDataGridViewTextBoxColumn.HeaderText = "Limite";
            this.limiteDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.limiteDataGridViewTextBoxColumn.Name = "limiteDataGridViewTextBoxColumn";
            this.limiteDataGridViewTextBoxColumn.Width = 125;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(876, 488);
            this.ControlBox = false;
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.fillByToolStrip);
            this.Controls.Add(this.button2);
            this.HelpButton = true;
            this.Name = "Form1";
            this.Text = "BTG Pactual";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDocumento)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.limite1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bTGDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.limiteBindingSource1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.limiteBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btgDataSet11)).EndInit();
            this.fillByToolStrip.ResumeLayout(false);
            this.fillByToolStrip.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.BindingSource limiteBindingSource;
        private System.Windows.Forms.DataGridView dgvDocumento;
        private System.Windows.Forms.BindingSource limiteBindingSource1;
        private System.Windows.Forms.Label lblDocumento;
        private System.Windows.Forms.Label lblAgencia;
        private System.Windows.Forms.Label lblConta;
        private System.Windows.Forms.Label lblLimite;
        private System.Windows.Forms.TextBox txtDocumento;
        private System.Windows.Forms.TextBox txtAgencia;
        private System.Windows.Forms.TextBox txtConta;
        private System.Windows.Forms.TextBox txtLimite;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private BTGDataSet1 btgDataSet11;
        private System.Windows.Forms.TextBox txtDocumentoAlter;
        private System.Windows.Forms.ToolStripButton tsbExcluir;
        private System.Windows.Forms.ToolStripButton tsbIncluir;
        private System.Windows.Forms.ToolStripButton tsbAlterar;
        private System.Windows.Forms.ToolStripButton tsbSair;
        private System.Windows.Forms.ToolStrip fillByToolStrip;
        private BTGDataSet1TableAdapters.TableAdapterManager Limite1TableAdapter;
        private BTGDataSet bTGDataSet;
        private System.Windows.Forms.BindingSource limite1BindingSource;
        private BTGDataSetTableAdapters.Limite1TableAdapter limite1TableAdapter1;
        private System.Windows.Forms.Button btnPix;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtLimiteTransferencia;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn documentoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numeroAgenciaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numeroContaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn limiteDataGridViewTextBoxColumn;
    }
}

